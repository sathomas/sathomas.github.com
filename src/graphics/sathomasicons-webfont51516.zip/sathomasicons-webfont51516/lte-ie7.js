/* Use this script if you need to support IE 7 and IE 6. */

window.onload = function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'sathomasicons-webfont\'">' + entity + '</span>' + html;
	}
	var icons = {
			'icon-twitter' : '&#x54;',
			'icon-feed' : '&#x52;',
			'icon-github' : '&#x47;',
			'icon-comments' : '&#x53;',
			'icon-envelope' : '&#x45;',
			'icon-home' : '&#x48;',
			'icon-info' : '&#x49;'
		},
		els = document.getElementsByTagName('*'),
		i, attr, html, c, el;
	for (i = 0; i < els.length; i += 1) {
		el = els[i];
		attr = el.getAttribute('data-icon');
		if (attr) {
			addIcon(el, attr);
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c) {
			addIcon(el, icons[c[0]]);
		}
	}
};